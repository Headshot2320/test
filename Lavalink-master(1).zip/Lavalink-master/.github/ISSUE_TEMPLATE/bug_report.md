---
name: Technical issue
about: Use this if you are having a problem with Lavalink
title: ''
labels: ''
assignees: ''

---

## Description
<!-- Please describe the issue in details -->


## Version info
**Client used:** <!-- The library you use to connect to Lavalink -->

Output of `java -version`:
```
(paste here)
```

<!-- You must include your lavalink logs -->
<!-- If you can't provide a log, at least provide the output of "java -jar Lavalink.jar --version" -->
